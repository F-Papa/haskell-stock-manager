module Main (main) where

import Control.Concurrent (MVar, forkIO, newEmptyMVar, putMVar, takeMVar, threadDelay)
import Control.Exception (SomeException, try)
import Data.List
import qualified Data.Map as M
import Data.Maybe
import Network.Socket
import System.Environment (getArgs)
import System.IO
import System.Random

type StockMap = M.Map ProductId ProductQuantity

type ProductId = Int

data ProductQuantity = ProductQuantity {getReserved :: Int, getAvailable :: Int} deriving (Show)

main :: IO ()
main = do
  args <- getArgs
  let serverPort = parsePort (listToMaybe args)
  serverSock <- bindSockAndListen serverPort
  mutex <- newEmptyMVar
  stock <- readStockFromFile
  putMVar mutex stock
  putStrLn $ "Listening on: " ++ show serverPort
  go serverSock mutex
  where
    go serverSock mutex = do
      (clientSock, addr) <- accept serverSock
      putStrLn $ "Connected to: " ++ show addr
      _ <- forkIO (handleClient (show addr) clientSock mutex)
      go serverSock mutex

readStockFromFile :: IO StockMap
readStockFromFile = do
  fHandle <- openFile "data/stock.txt" ReadMode
  go M.empty fHandle
  where
    go :: StockMap -> Handle -> IO StockMap
    go stockMap fHandle = do
      result <- try (hGetLine fHandle) :: IO (Either SomeException String)
      case result of
        Left _ -> return stockMap
        Right line ->
          let (p, q) = parseLine line
           in go (M.insert p q stockMap) fHandle

parseLine :: String -> (ProductId, ProductQuantity)
parseLine l = fmap mkStruct (splitOnComma l)
  where
    mkStruct :: Int -> ProductQuantity
    mkStruct x = ProductQuantity {getReserved = 0, getAvailable = x}

splitOnComma' :: String -> (String, String)
splitOnComma' l = (pId, quantity)
  where
    pId = take sepIdx l
    quantity = drop (sepIdx + 1) l
    sepIdx = fromJust (elemIndex ',' l)

splitOnComma :: String -> (ProductId, Int)
splitOnComma l = (read pId, read quantity)
  where
    pId = take sepIdx l
    quantity = drop (sepIdx + 1) l
    sepIdx = fromJust (elemIndex ',' l)

handleClient :: String -> Socket -> MVar StockMap -> IO ()
handleClient clientId sock mutex = do
  handle <- socketToHandle sock ReadWriteMode
  go handle
  where
    go h = do
      result <- try (hGetLine h) :: IO (Either SomeException String)
      case result of
        Left _ -> putStrLn "Client connection failed"
        Right line -> do
          print (splitOnComma' line)
          let (pId, quant) = splitOnComma line
           in takeReservation clientId mutex pId quant
      go h

noStock :: ProductQuantity
noStock = ProductQuantity 0 0

takeReservation :: String -> MVar StockMap -> ProductId -> Int -> IO ()
takeReservation clientId mutex prodId quantity = do
  stock <- takeMVar mutex

  case fromMaybe noStock (M.lookup prodId stock) of
    (ProductQuantity resv avail)
      | (avail - quantity) >= 0 ->
          do
            putStrLn $ "[" ++ show clientId ++ "] Reserved " ++ show quantity ++ " of " ++ show prodId
            let newQuant = ProductQuantity {getAvailable = avail - quantity, getReserved = resv}
            putMVar mutex $ M.insert prodId newQuant stock
            _ <- forkIO (maybeCompleteTransaction mutex prodId quantity)
            return ()
    (ProductQuantity _ avail) -> do
      putStrLn $ "[" ++ show clientId ++ "] Insufficient stock (" ++ show avail ++ ") for reserving " ++ show quantity ++ " of " ++ show prodId
      return ()

maybeCompleteTransaction :: MVar StockMap -> ProductId -> Int -> IO ()
maybeCompleteTransaction stockMutex pId quantity = do
  threadDelay 1000000
  num <- randomRIO (0, 1) :: IO Float
  stock <- takeMVar stockMutex
  let current@(ProductQuantity reserved available) = fromMaybe noStock (M.lookup pId stock)
  if num >= 0.5
    then do
      putStrLn $ "Transaction of " ++ show quantity ++ "succeeded"
      putMVar stockMutex (M.insert pId current {getReserved = reserved - quantity} stock)
    else do
      putStrLn $ "Transaction of " ++ show quantity ++ "failed"
      putMVar stockMutex (M.insert pId current {getAvailable = available + quantity, getReserved = reserved - reserved} stock)
  return ()

bindSockAndListen :: PortNumber -> IO Socket
bindSockAndListen port = do
  sock <- socket AF_INET Stream defaultProtocol
  bind sock (SockAddrInet port 0)
  listen sock backlog
  return sock
  where
    backlog = 5

parsePort :: Maybe String -> PortNumber
parsePort = maybe 3000 read
